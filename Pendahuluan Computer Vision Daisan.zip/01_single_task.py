import os
import argparse
import cv2
import numpy as np
import matplotlib.pyplot as plt


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)


def print_props(img, name="image"):
    if img is None:
        print(f"{name} is None")
        return
    h, w = img.shape[:2]
    ch = 1 if img.ndim == 2 else img.shape[2]
    print(f"{name}: width={w}, height={h}, channels={ch}, dtype={img.dtype}, shape={img.shape}")


def show_with_matplotlib(title, img_rgb):
    plt.figure(figsize=(6, 4))
    plt.axis('off')
    plt.title(title)
    plt.imshow(img_rgb)
    plt.show()


def main():
    parser = argparse.ArgumentParser(description="Single-file CV demo: load, inspect, convert, draw, save")
    parser.add_argument('--input', '-i', default=os.path.join('data', 'images', 'sample.jpg'),
                        help='Input image path (default: data/images/sample.jpg)')
    parser.add_argument('--output', '-o', default=os.path.join('praktikum', 'output'),
                        help='Output folder (default: praktikum/output)')
    parser.add_argument('--no-show', action='store_true', help='Do not display images interactively')
    args = parser.parse_args()

    ensure_dir(args.output)

    img_bgr = cv2.imread(args.input, cv2.IMREAD_COLOR)
    if img_bgr is None:
        print(f"Failed to load image: {args.input}")
        return

    # 1) Print properties
    print_props(img_bgr, 'Original (BGR)')

    # 2) Convert color spaces
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    img_gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    img_hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)

    print_props(img_rgb, 'RGB')
    print_props(img_gray, 'Grayscale')
    print_props(img_hsv, 'HSV')

    # 3) Pixel manipulation: darken a region and swap channels in a ROI
    h, w = img_bgr.shape[:2]
    # ROI coordinates
    x1, y1 = int(w * 0.05), int(h * 0.05)
    x2, y2 = int(w * 0.35), int(h * 0.35)
    img_manip = img_bgr.copy()
    # darken ROI by 60%
    img_manip[y1:y2, x1:x2] = (img_manip[y1:y2, x1:x2] * 0.4).astype(np.uint8)
    # swap red and blue in another ROI
    sx1, sy1 = int(w * 0.6), int(h * 0.1)
    sx2, sy2 = int(w * 0.95), int(h * 0.4)
    roi = img_manip[sy1:sy2, sx1:sx2]
    if roi.size:
        roi = roi[..., ::-1]  # BGR->RGB swap inside roi
        img_manip[sy1:sy2, sx1:sx2] = roi

    # 4) Drawing shapes and text
    img_draw = img_bgr.copy()
    cv2.rectangle(img_draw, (x1, y1), (x2, y2), (0, 255, 0), 2)
    cv2.circle(img_draw, (int(w*0.8), int(h*0.75)), int(min(w, h)*0.08), (255, 0, 0), 3)
    cv2.putText(img_draw, 'Praktikum CV 01', (10, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)

    # 5) Arithmetic: blend original and manipulated
    img_blend = cv2.addWeighted(img_bgr, 0.6, img_manip, 0.4, 0)

    # 6) Save outputs
    def save(name, img):
        path = os.path.join(args.output, name)
        cv2.imwrite(path, img)
        print(f"Saved: {path}")

    save('original.jpg', img_bgr)
    save('rgb.png', cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR))
    save('gray.png', img_gray)
    save('hsv.png', cv2.cvtColor(img_hsv, cv2.COLOR_HSV2BGR))
    save('manipulated.jpg', img_manip)
    save('drawn.jpg', img_draw)
    save('blend.jpg', img_blend)

    # 7) Optionally show images using matplotlib (RGB order)
    if not args.no_show:
        show_with_matplotlib('Original (RGB)', img_rgb)
        show_with_matplotlib('Grayscale', img_gray,)
        show_with_matplotlib('Manipulated (RGB)', cv2.cvtColor(img_manip, cv2.COLOR_BGR2RGB))
        show_with_matplotlib('Drawn (RGB)', cv2.cvtColor(img_draw, cv2.COLOR_BGR2RGB))
        show_with_matplotlib('Blend (RGB)', cv2.cvtColor(img_blend, cv2.COLOR_BGR2RGB))


if __name__ == '__main__':
    main()
